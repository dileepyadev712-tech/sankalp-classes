/* DARK MODE */

function toggleMode() {
  document.body.classList.toggle("light")
}

/* SHOW SECTION */

function show(id) {
  document.querySelectorAll("section").forEach(s => s.style.display = "none")
  document.getElementById(id).style.display = "block"
}

/* REGISTER */

function register() {
  
  let u = regUser.value
  let p = regPass.value
  let g = regGrade.value
  
  localStorage.setItem("student_" + u, p)
  localStorage.setItem("grade_" + u, g)
  
  alert("Account created")
  
  show("login")
  
}

/* LOGIN */

function login() {
  
  let u = loginUser.value
  let p = loginPass.value
  
  if (localStorage.getItem("student_" + u) == p) {
    
    localStorage.setItem("currentStudent", u)
    
    let grade = localStorage.getItem("grade_" + u)

let grade = localStorage.getItem("grade_" + u)

let classNumber = grade.replace("Class ", "")

let fee = fees[classNumber]

studentName.innerText = "Welcome " + u + " (" + grade + ") | Fee: " + fee
    
    loadResults()
    
    show("dashboard")
    
  }
  
  else alert("Wrong login")
  
}

/* QUIZ */

let questions = [
  { q: "Speed formula?", a: ["distance/time", "time/speed", "mass*velocity"], c: 0 },
  { q: "H2O is?", a: ["Oxygen", "Water", "Hydrogen"], c: 1 },
  { q: "5+7=?", a: ["10", "12", "13"], c: 1 }
]

function startQuiz() {
  
  quizBox.innerHTML = ""
  
  questions.forEach((q, i) => {
    
    let html = `<p>${q.q}</p>`
    
    q.a.forEach((o, j) => {
      html += `<label><input type="radio" name="q${i}" value="${j}">${o}</label><br>`
    })
    
    quizBox.innerHTML += html
    
  })
  
  show("quiz")
  
}

function submitQuiz() {
  
  let score = 0
  
  questions.forEach((q, i) => {
    
    let ans = document.querySelector(`input[name=q${i}]:checked`)
    
    if (ans && ans.value == q.c) score++
    
  })
  
  let user = localStorage.getItem("currentStudent")
  
  let r = JSON.parse(localStorage.getItem("results_" + user) || "[]")
  
  r.push({ date: new Date().toLocaleDateString(), score: score })
  
  localStorage.setItem("results_" + user, JSON.stringify(r))
  
  show("dashboard")
  
  loadResults()
  
}

function loadResults() {
  
  let user = localStorage.getItem("currentStudent")
  
  let r = JSON.parse(localStorage.getItem("results_" + user) || "[]")
  
  results.innerHTML = ""
  
  r.forEach(x => {
    results.innerHTML += `<li>${x.date} : ${x.score}</li>`
  })
  
}

/* PARTICLES */

const canvas = document.getElementById("particles")
const ctx = canvas.getContext("2d")

canvas.width = innerWidth
canvas.height = innerHeight

let particles = []

for (let i = 0; i < 80; i++) {
  particles.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: Math.random() * 3
  })
}

function animate() {
  
  ctx.clearRect(0, 0, canvas.width, canvas.height)
  
  ctx.fillStyle = "#00f2fe"
  
  particles.forEach(p => {
    
    ctx.beginPath()
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
    ctx.fill()
    
    p.y += 0.3
    if (p.y > canvas.height) p.y = 0
    
  })
  
  requestAnimationFrame(animate)
  
}

animate()

/* ADMIN PANEL */

const ADMIN_PASS = "lumina123"
let taps = 0
let timer = null

document.addEventListener("click", e => {
  
  if (e.clientY < 80) {
    
    taps++
    
    clearTimeout(timer)
    
    timer = setTimeout(() => taps = 0, 1500)
    
    if (taps >= 10) {
      
      taps = 0
      
      let pass = prompt("Enter Admin Password")
      
      if (pass === ADMIN_PASS) {
        openAdmin()
      }
      
    }
    
  }
  
})

function openAdmin() {
  
  adminPanel.style.display = "block"
  
  editHero.value = heroTitle.innerText
  editPhysics.value = physicsTeacher.innerText
  editMath.value = mathTeacher.innerText
  editBio.value = bioTeacher.innerText
  editFee1.value = feePrimary.innerText
  editFee2.value = feeHigh.innerText
  
}

function closeAdmin() {
  adminPanel.style.display = "none"
}

function saveAdmin() {
  
  localStorage.setItem("heroTitle", editHero.value)
  localStorage.setItem("physicsTeacher", editPhysics.value)
  localStorage.setItem("mathTeacher", editMath.value)
  localStorage.setItem("bioTeacher", editBio.value)
  localStorage.setItem("feePrimary", editFee1.value)
  localStorage.setItem("feeHigh", editFee2.value)
  
  loadAdmin()
  
}

function loadAdmin() {
  
  if (localStorage.heroTitle)
    heroTitle.innerText = localStorage.heroTitle
  
  if (localStorage.physicsTeacher)
    physicsTeacher.innerText = localStorage.physicsTeacher
  
  if (localStorage.mathTeacher)
    mathTeacher.innerText = localStorage.mathTeacher
  
  if (localStorage.bioTeacher)
    bioTeacher.innerText = localStorage.bioTeacher
  
  if (localStorage.feePrimary)
    feePrimary.innerText = localStorage.feePrimary
  
  if (localStorage.feeHigh)
    feeHigh.innerText = localStorage.feeHigh
  
}

function resetSite() {
  localStorage.clear()
  location.reload()
}

loadAdmin()


/* CLASS FEES */

const classFees = {

1: "₹800",
2: "₹900",
3: "₹1000",
4: "₹1100",
5: "₹1200",

6: "₹1500",
7: "₹1700",
8: "₹1900",
9: "₹2200",
10: "₹2500"

}

function showFee() {
  
  let grade = document.getElementById("regGrade").value
  
  if (!grade) {
    document.getElementById("classFee").innerText = ""
    return
  }
  
  let number = grade.replace("Class ", "")
  
  let fee = classFees[number]
  
  document.getElementById("classFee").innerText =
    "Monthly Fee: " + fee
  
}